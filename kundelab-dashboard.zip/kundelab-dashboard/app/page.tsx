import { redirect } from 'next/navigation';
import { createServerClientFromCookies } from '@/lib/supabaseServer';
import DashboardApp from '@/components/DashboardApp';

export default async function Home() {
  const supabase = await createServerClientFromCookies();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  return <DashboardApp userEmail={user.email ?? ''} />;
}
