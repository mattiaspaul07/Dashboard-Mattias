'use client';
import { createClient } from '@/lib/supabaseClient';

export default function LoginPage() {
  async function signIn() {
    const supabase = createClient();
    await supabase.auth.signInWithOAuth({
      provider: 'azure',
      options: {
        scopes: 'openid profile email',
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });
  }
  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', background: 'var(--bg)' }}>
      <div style={{ textAlign: 'center', background: '#fff', padding: 40, borderRadius: 14, boxShadow: 'var(--shadow-lg)', maxWidth: 360 }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/logo.png" alt="Kundelab" width={56} height={56} style={{ borderRadius: '50%' }} />
        <h1 style={{ fontSize: 20, margin: '16px 0 4px', color: 'var(--brand)' }}>Kundelab Dashboard</h1>
        <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 24 }}>Sign in with your Microsoft 365 account.</p>
        <button className="btn primary" style={{ width: '100%', justifyContent: 'center' }} onClick={signIn}>
          Sign in with Microsoft
        </button>
      </div>
    </div>
  );
}
