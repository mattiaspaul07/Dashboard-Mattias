// POST to create a Graph change-notification subscription on the mailbox inbox.
// Call once after deploy (and the renew cron keeps it alive).
import { NextResponse } from 'next/server';
import { getAppToken, graphFetch, subscriptionExpiry, mailbox } from '@/lib/graph';
import { createServiceClient } from '@/lib/supabaseServer';

export async function POST() {
  try {
    const token = await getAppToken();
    const sub = await graphFetch(token, '/subscriptions', {
      method: 'POST',
      body: JSON.stringify({
        changeType: 'created',
        notificationUrl: `${process.env.NEXT_PUBLIC_SITE_URL}/api/graph/notifications`,
        resource: `/users/${mailbox()}/mailFolders('inbox')/messages`,
        expirationDateTime: subscriptionExpiry(),
        clientState: process.env.GRAPH_WEBHOOK_SECRET,
      }),
    });
    const db = createServiceClient();
    await db.from('graph_subscriptions').insert({
      subscription_id: sub.id, expiration: sub.expirationDateTime,
    });
    return NextResponse.json({ ok: true, subscriptionId: sub.id });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: String(e?.message ?? e) }, { status: 500 });
  }
}
