// Hit by Vercel Cron (see vercel.json). Extends each active subscription before the ~3-day cap.
import { NextResponse } from 'next/server';
import { getAppToken, graphFetch, subscriptionExpiry } from '@/lib/graph';
import { createServiceClient } from '@/lib/supabaseServer';

export async function GET() {
  try {
    const db = createServiceClient();
    const token = await getAppToken();
    const { data: subs } = await db.from('graph_subscriptions').select('*');
    for (const s of subs ?? []) {
      const updated = await graphFetch(token, `/subscriptions/${s.subscription_id}`, {
        method: 'PATCH',
        body: JSON.stringify({ expirationDateTime: subscriptionExpiry() }),
      });
      await db.from('graph_subscriptions')
        .update({ expiration: updated.expirationDateTime })
        .eq('subscription_id', s.subscription_id);
    }
    return NextResponse.json({ ok: true, renewed: subs?.length ?? 0 });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: String(e?.message ?? e) }, { status: 500 });
  }
}
