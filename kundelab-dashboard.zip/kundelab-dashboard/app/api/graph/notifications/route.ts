// Receives Graph change notifications.
// 1) Validation handshake: echo back ?validationToken as text/plain within ~10s.
// 2) On a real notification: fetch the message, dedup, create a task in the inbox (unapproved).
import { NextResponse } from 'next/server';
import { getAppToken, graphFetch, mailbox } from '@/lib/graph';
import { createServiceClient } from '@/lib/supabaseServer';

export async function POST(request: Request) {
  const url = new URL(request.url);
  const validationToken = url.searchParams.get('validationToken');
  if (validationToken) {
    return new NextResponse(validationToken, { status: 200, headers: { 'Content-Type': 'text/plain' } });
  }

  const body = await request.json();
  const db = createServiceClient();
  const token = await getAppToken();

  for (const note of body.value ?? []) {
    if (note.clientState !== process.env.GRAPH_WEBHOOK_SECRET) continue; // reject spoofed calls
    const msgId = note.resourceData?.id;
    if (!msgId) continue;

    // Dedup: skip if we've already processed this message.
    const { data: existing } = await db.from('email_events').select('id').eq('graph_message_id', msgId).maybeSingle();
    if (existing) continue;

    // TODO: resolve owner_id. For a single-user dashboard this is your user id;
    // store it in an env var or a settings table. Left explicit on purpose.
    const ownerId = process.env.DASHBOARD_OWNER_ID;
    if (!ownerId) continue;

    const msg = await graphFetch(token, `/users/${mailbox()}/messages/${msgId}?$select=subject,bodyPreview,from`);
    const fromAddr: string = msg.from?.emailAddress?.address ?? '';
    const domain = fromAddr.split('@')[1] ?? null;

    // Try to match a customer by email domain.
    let customerId: string | null = null;
    if (domain) {
      const { data: cust } = await db.from('customers')
        .select('id').eq('owner_id', ownerId).eq('email_domain', domain).maybeSingle();
      customerId = cust?.id ?? null;
    }

    const { data: task } = await db.from('tasks').insert({
      owner_id: ownerId,
      customer_id: customerId,
      title: msg.subject || '(no subject)',
      description: msg.bodyPreview || '',
      status: 'inbox',
      source: 'email',
      approved: false,         // requires manual approval before it leaves the inbox
    }).select('id').single();

    await db.from('email_events').insert({
      owner_id: ownerId, graph_message_id: msgId, task_id: task?.id ?? null,
    });
  }
  return NextResponse.json({ ok: true });
}
