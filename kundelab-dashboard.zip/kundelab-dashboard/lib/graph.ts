// Microsoft Graph helpers - app-only (client credentials) flow for the mail mailbox.
// See Section 3b/5 of the setup guide. NOTE: subscribe against /users/{mailbox}/messages,
// NOT /me/messages (which requires a signed-in user).

const GRAPH = 'https://graph.microsoft.com/v1.0';

export async function getAppToken(): Promise<string> {
  const tenant = process.env.MS_TENANT_ID!;
  const body = new URLSearchParams({
    client_id: process.env.MS_CLIENT_ID!,
    client_secret: process.env.MS_CLIENT_SECRET!,
    scope: 'https://graph.microsoft.com/.default',
    grant_type: 'client_credentials',
  });
  const res = await fetch(`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!res.ok) throw new Error(`Token request failed: ${res.status} ${await res.text()}`);
  return (await res.json()).access_token as string;
}

export async function graphFetch(token: string, path: string, init: RequestInit = {}) {
  const res = await fetch(`${GRAPH}${path}`, {
    ...init,
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
  if (!res.ok) throw new Error(`Graph ${path} failed: ${res.status} ${await res.text()}`);
  return res.status === 204 ? null : res.json();
}

// Mail subscriptions cap at ~4230 min (~3 days). We renew well inside that via cron.
export function subscriptionExpiry(minutes = 4000): string {
  return new Date(Date.now() + minutes * 60_000).toISOString();
}

export function mailbox() { return encodeURIComponent(process.env.MS_MAILBOX!); }
