export type TaskStatus =
  | 'inbox' | 'new' | 'todo' | 'in_progress'
  | 'waiting_customer' | 'waiting_internal' | 'review' | 'completed';
export type Priority = 'urgent' | 'high' | 'medium' | 'low';
export type TaskType = 'new' | 'modify' | 'delete';

export interface Customer {
  id: string;
  name: string;
  org: string | null;
  instance: string | null;
  workspace: string | null;
  email_domain: string | null;
  last_comm: string | null;
}

export interface Task {
  id: string;
  customer_id: string | null;
  title: string;
  description: string;
  status: TaskStatus;
  priority: Priority;
  type: TaskType;
  source: 'email' | 'manual';
  workspace: string | null;
  due_date: string | null;
  tags: string[];
  time_min: number;
  approved: boolean;
  created_at: string;
}

export const COLUMNS: { id: TaskStatus; name: string; color: string }[] = [
  { id: 'inbox', name: 'Inbox', color: '#9aa1ad' },
  { id: 'new', name: 'New', color: '#2D7FF9' },
  { id: 'todo', name: 'To do', color: '#7A5AF8' },
  { id: 'in_progress', name: 'In progress', color: '#FF5A1F' },
  { id: 'waiting_customer', name: 'Waiting for customer', color: '#E8A302' },
  { id: 'waiting_internal', name: 'Waiting for internal', color: '#0FB5BA' },
  { id: 'review', name: 'Review', color: '#D957C7' },
  { id: 'completed', name: 'Completed', color: '#18A957' },
];
export const PRIORITIES: Record<Priority, string> = { urgent: 'Urgent', high: 'High', medium: 'Medium', low: 'Low' };
export const TYPES: Record<TaskType, string> = { new: 'New', modify: 'Modify', delete: 'Delete' };
