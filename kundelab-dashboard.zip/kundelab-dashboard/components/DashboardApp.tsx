'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createClient } from '@/lib/supabaseClient';
import {
  Task, Customer, TaskStatus, Priority, TaskType,
  COLUMNS, PRIORITIES, TYPES,
} from '@/lib/types';

const ONE_DAY = 86400000;
const todayMid = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const parseDate = (s: string | null) => { if (!s) return null; const d = new Date(s + 'T00:00:00'); return isNaN(+d) ? null : d; };
function dueClass(s: string | null) {
  const d = parseDate(s); if (!d) return 'later';
  const diff = Math.round((+d - +todayMid()) / ONE_DAY);
  if (diff < 0) return 'overdue'; if (diff === 0) return 'today'; if (diff <= 3) return 'soon'; return 'later';
}
function dueLabel(s: string | null) {
  const d = parseDate(s); if (!d) return 'No due date';
  const diff = Math.round((+d - +todayMid()) / ONE_DAY);
  if (diff === 0) return 'Due today'; if (diff === -1) return 'Yesterday'; if (diff < 0) return `${-diff}d overdue`;
  if (diff === 1) return 'Tomorrow'; if (diff <= 6) return `In ${diff}d`;
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}
function daysAgo(iso: string) {
  const diff = Math.round((+todayMid() - +new Date(iso)) / ONE_DAY);
  if (diff <= 0) return 'today'; if (diff === 1) return '1 day ago'; if (diff < 7) return `${diff} days ago`;
  return `${Math.floor(diff / 7)}w ago`;
}
function fmtTime(m: number) { if (!m) return '0m'; const h = Math.floor(m / 60), mm = m % 60; return h ? `${h}h${mm ? ` ${mm}m` : ''}` : `${mm}m`; }

type View = 'dashboard' | 'kanban' | 'customers' | 'reports';
const VIEW_TITLES: Record<View, string> = { dashboard: 'Dashboard', kanban: 'Kanban board', customers: 'Customers', reports: 'Reports' };

const emptyTask = (status: TaskStatus = 'inbox'): Partial<Task> => ({
  title: '', description: '', customer_id: null, status, priority: 'medium',
  type: 'new', workspace: '', due_date: null, tags: [], time_min: 0,
});

export default function DashboardApp({ userEmail }: { userEmail: string }) {
  const supabase = useMemo(() => createClient(), []);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<View>('dashboard');
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({ customer: '', priority: '', type: '', due: '' });
  const [navOpen, setNavOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [taskDraft, setTaskDraft] = useState<Partial<Task> | null>(null); // open task modal when non-null
  const [custDraft, setCustDraft] = useState<Partial<Customer> | null>(null);

  const toast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(''), 2200);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: t }, { data: c }] = await Promise.all([
      supabase.from('tasks').select('*').order('created_at', { ascending: false }),
      supabase.from('customers').select('*').order('name'),
    ]);
    setTasks((t as Task[]) ?? []);
    setCustomers((c as Customer[]) ?? []);
    setLoading(false);
  }, [supabase]);

  useEffect(() => { load(); }, [load]);

  const custName = useCallback((id: string | null) => customers.find(c => c.id === id)?.name ?? 'Unassigned', [customers]);

  // ---------- mutations ----------
  async function saveTask(draft: Partial<Task>) {
    if (!draft.title?.trim()) { toast('Title is required'); return; }
    const payload = {
      title: draft.title.trim(), description: draft.description ?? '', customer_id: draft.customer_id || null,
      status: draft.status, priority: draft.priority, type: draft.type, workspace: draft.workspace?.trim() || null,
      due_date: draft.due_date || null, tags: draft.tags ?? [], time_min: draft.time_min ?? 0,
    };
    if (draft.id) {
      const { data, error } = await supabase.from('tasks').update(payload).eq('id', draft.id).select().single();
      if (error) return toast(error.message);
      setTasks(prev => prev.map(t => (t.id === draft.id ? (data as Task) : t)));
      toast('Task updated');
    } else {
      const { data, error } = await supabase.from('tasks').insert({ ...payload, source: 'manual', approved: true }).select().single();
      if (error) return toast(error.message);
      setTasks(prev => [data as Task, ...prev]);
      toast('Task created');
    }
    setTaskDraft(null);
  }
  async function deleteTask(id: string) {
    const { error } = await supabase.from('tasks').delete().eq('id', id);
    if (error) return toast(error.message);
    setTasks(prev => prev.filter(t => t.id !== id));
    setTaskDraft(null); toast('Task deleted');
  }
  async function moveTask(id: string, status: TaskStatus) {
    setTasks(prev => prev.map(t => (t.id === id ? { ...t, status } : t)));
    const { error } = await supabase.from('tasks').update({ status }).eq('id', id);
    if (error) { toast(error.message); load(); }
    else toast(`Moved to ${COLUMNS.find(c => c.id === status)!.name}`);
  }
  async function saveCustomer(draft: Partial<Customer>) {
    if (!draft.name?.trim()) { toast('Name is required'); return; }
    const payload = {
      name: draft.name.trim(), org: draft.org ?? null, instance: draft.instance ?? null,
      workspace: draft.workspace ?? null, email_domain: draft.email_domain ?? null,
    };
    if (draft.id) {
      const { data, error } = await supabase.from('customers').update(payload).eq('id', draft.id).select().single();
      if (error) return toast(error.message);
      setCustomers(prev => prev.map(c => (c.id === draft.id ? (data as Customer) : c)));
      toast('Customer updated');
    } else {
      const { data, error } = await supabase.from('customers').insert({ ...payload, last_comm: new Date().toISOString().slice(0, 10) }).select().single();
      if (error) return toast(error.message);
      setCustomers(prev => [...prev, data as Customer].sort((a, b) => a.name.localeCompare(b.name)));
      toast('Customer added');
    }
    setCustDraft(null);
  }
  async function deleteCustomer(id: string) {
    if (tasks.some(t => t.customer_id === id) && !confirm('This customer has tasks. They will be set to Unassigned. Continue?')) return;
    const { error } = await supabase.from('customers').delete().eq('id', id);
    if (error) return toast(error.message);
    setCustomers(prev => prev.filter(c => c.id !== id));
    setTasks(prev => prev.map(t => (t.customer_id === id ? { ...t, customer_id: null } : t)));
    setCustDraft(null); toast('Customer deleted');
  }

  async function signOut() { await supabase.auth.signOut(); window.location.href = '/login'; }

  // ---------- derived ----------
  const visibleTasks = useMemo(() => {
    const term = search.trim().toLowerCase();
    return tasks.filter(t => {
      if (filters.customer && t.customer_id !== filters.customer) return false;
      if (filters.priority && t.priority !== filters.priority) return false;
      if (filters.type && t.type !== filters.type) return false;
      if (filters.due) {
        const cl = dueClass(t.due_date);
        if (filters.due === 'overdue' && cl !== 'overdue') return false;
        if (filters.due === 'today' && cl !== 'today') return false;
        if (filters.due === 'week' && !['overdue', 'today', 'soon'].includes(cl)) return false;
      }
      if (term) {
        const hay = `${t.title} ${t.description} ${custName(t.customer_id)} ${(t.tags || []).join(' ')}`.toLowerCase();
        if (!hay.includes(term)) return false;
      }
      return true;
    });
  }, [tasks, filters, search, custName]);

  const notifications = useMemo(() => {
    const open = tasks.filter(t => t.status !== 'completed');
    const items: { id: string; tone: string; title: string; sub: string }[] = [];
    open.filter(t => dueClass(t.due_date) === 'overdue').forEach(t => items.push({ id: t.id, tone: 'bad', title: t.title, sub: `Overdue - ${custName(t.customer_id)}` }));
    open.filter(t => dueClass(t.due_date) === 'today').forEach(t => items.push({ id: t.id, tone: 'warn', title: t.title, sub: `Due today - ${custName(t.customer_id)}` }));
    tasks.filter(t => t.status === 'inbox' && t.source === 'email').forEach(t => items.push({ id: t.id, tone: 'info', title: t.title, sub: `New email - ${custName(t.customer_id)}` }));
    return items;
  }, [tasks, custName]);

  // ---------- small render helpers ----------
  const PriorityChip = ({ p }: { p: Priority }) => <span className={`chip p-${p}`}><span className="pdot" />{PRIORITIES[p]}</span>;
  const TypeChip = ({ t }: { t: TaskType }) => <span className={`type-chip t-${t}`}>{TYPES[t]}</span>;
  const Due = ({ s }: { s: string | null }) => <span className={`due ${dueClass(s)}`}>{dueLabel(s)}</span>;
  const WsLink = ({ url }: { url: string | null }) => url
    ? <a className="ws-link" href={url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}>↗ Workspace</a> : null;

  function openSearch(v: string) { setSearch(v); if (v.trim() && view !== 'customers') setView('kanban'); }

  if (loading) return <div className="empty" style={{ padding: 80 }}>Loading your workspace…</div>;

  return (
    <div className="app">
      <aside className={`sidebar${navOpen ? ' open' : ''}`}>
        <div className="logo">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.png" alt="Kundelab" /><div className="name">Kundelab</div>
        </div>
        {(['dashboard', 'kanban', 'customers', 'reports'] as View[]).map(v => (
          <button key={v} className={`nav-item${view === v ? ' active' : ''}`} onClick={() => { setView(v); setNavOpen(false); }}>
            {VIEW_TITLES[v]}
          </button>
        ))}
        <div className="nav-spacer" />
        <div className="sidebar-foot">
          {userEmail}<br /><button onClick={signOut}>Sign out</button>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <button className="menu-btn" onClick={() => setNavOpen(o => !o)} aria-label="Menu">≡</button>
          <h1>{VIEW_TITLES[view]}</h1>
          <div className="search">
            <span className="s-ico">⌕</span>
            <input value={search} onChange={e => openSearch(e.target.value)} placeholder="Search tasks and customers..." type="search" />
          </div>
          <div className="top-actions">
            <button className="bell" onClick={() => setNotifOpen(o => !o)} aria-label="Notifications">
              🔔{notifications.length > 0 && <span className="dot">{notifications.length}</span>}
            </button>
            <button className="btn primary" onClick={() => setTaskDraft(emptyTask())}>+ New task</button>
          </div>
        </header>

        {notifOpen && (
          <div className="notif open">
            <div className="notif-h">Notifications</div>
            <div className="notif-list">
              {notifications.length ? notifications.map((n, i) => (
                <div key={i} className="notif-item" style={{ cursor: 'pointer' }}
                  onClick={() => { const t = tasks.find(x => x.id === n.id); if (t) setTaskDraft(t); setNotifOpen(false); }}>
                  <div className="ni-ic" style={{ background: 'var(--brand-soft)', color: 'var(--brand)' }}>•</div>
                  <div><div className="ni-t">{n.title}</div><div className="ni-s">{n.sub}</div></div>
                </div>
              )) : <div className="empty">You are all caught up</div>}
            </div>
          </div>
        )}

        <main className="content">
          {view === 'dashboard' && <DashboardView />}
          {view === 'kanban' && <KanbanView />}
          {view === 'customers' && <CustomersView />}
          {view === 'reports' && <ReportsView />}
        </main>
      </div>

      {taskDraft && <TaskModal />}
      {custDraft && <CustomerModal />}
      <div className={`toast${toastMsg ? ' show' : ''}`}>{toastMsg}</div>
    </div>
  );

  // ============ Views ============
  function DashboardView() {
    const open = tasks.filter(t => t.status !== 'completed');
    const overdue = open.filter(t => dueClass(t.due_date) === 'overdue');
    const dueToday = open.filter(t => dueClass(t.due_date) === 'today');
    const followups = tasks.filter(t => t.status === 'waiting_customer' || t.status === 'waiting_internal');
    const completed = tasks.filter(t => t.status === 'completed');
    const recent = [...tasks].slice(0, 5);
    const load: Record<string, number> = {};
    open.forEach(t => { const k = t.customer_id ?? 'none'; load[k] = (load[k] || 0) + 1; });
    const rows = Object.entries(load).sort((a, b) => b[1] - a[1]);
    const maxLoad = Math.max(1, ...rows.map(r => r[1]));
    const Stat = ({ label, value, sub, cls = '' }: any) =>
      <div className={`stat ${cls}`}><div className="label">{label}</div><div className="value">{value}</div><div className="sub">{sub}</div></div>;
    return (
      <>
        <div className="banner">⚠<div><b>Email-to-task</b> runs server-side via Microsoft Graph. Tasks flagged &quot;Email&quot; arrived in your inbox and may await approval.</div></div>
        <div className="stat-grid">
          <Stat label="Due today" value={dueToday.length} sub={dueToday.length ? 'Needs attention' : 'All clear'} cls="accent-warn" />
          <Stat label="Overdue" value={overdue.length} sub={overdue.length ? 'Past due date' : 'Nothing overdue'} cls="accent-bad" />
          <Stat label="Open tasks" value={open.length} sub={`${completed.length} completed`} />
          <Stat label="Follow-ups" value={followups.length} sub="Waiting on customer / team" />
        </div>
        <div className="two-col">
          <div className="panel">
            <div className="panel-h"><h2>Recently assigned</h2><button className="btn ghost" onClick={() => setView('kanban')}>View board</button></div>
            <div className="panel-b">
              {recent.map(t => (
                <div key={t.id} className="row-item" style={{ cursor: 'pointer' }} onClick={() => setTaskDraft(t)}>
                  <div className="ri-main"><div className="ri-title">{t.title}</div>
                    <div className="ri-meta">{custName(t.customer_id)} · {t.source === 'email' ? 'From email' : 'Manual'} · {daysAgo(t.created_at)}</div></div>
                  <TypeChip t={t.type} /><PriorityChip p={t.priority} /><Due s={t.due_date} />
                </div>
              ))}
              {!recent.length && <div className="empty">No tasks yet</div>}
            </div>
          </div>
          <div className="panel">
            <div className="panel-h"><h2>Workload by customer</h2></div>
            <div className="panel-b">
              {rows.length ? rows.map(([cid, n]) => (
                <div key={cid} className="bar-row"><div className="bl">{custName(cid === 'none' ? null : cid)}</div>
                  <div className="bar-track"><div className="bar-fill" style={{ width: `${(n / maxLoad) * 100}%` }} /></div><div className="bv">{n}</div></div>
              )) : <div className="empty">No open tasks</div>}
            </div>
          </div>
        </div>
        <div className="panel" style={{ marginTop: 18 }}>
          <div className="panel-h"><h2>Upcoming follow-ups</h2></div>
          <div className="panel-b">
            {followups.length ? followups.map(t => (
              <div key={t.id} className="row-item" style={{ cursor: 'pointer' }} onClick={() => setTaskDraft(t)}>
                <div className="ri-main"><div className="ri-title">{t.title}</div>
                  <div className="ri-meta">{custName(t.customer_id)} · {COLUMNS.find(c => c.id === t.status)!.name}</div></div><Due s={t.due_date} />
              </div>
            )) : <div className="empty">No follow-ups waiting</div>}
          </div>
        </div>
      </>
    );
  }

  function KanbanView() {
    return (
      <>
        <div className="filters">
          <select value={filters.customer} onChange={e => setFilters(f => ({ ...f, customer: e.target.value }))}>
            <option value="">All customers</option>{customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select value={filters.type} onChange={e => setFilters(f => ({ ...f, type: e.target.value }))}>
            <option value="">All types</option>{Object.entries(TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select value={filters.priority} onChange={e => setFilters(f => ({ ...f, priority: e.target.value }))}>
            <option value="">All priorities</option>{Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select value={filters.due} onChange={e => setFilters(f => ({ ...f, due: e.target.value }))}>
            <option value="">Any due date</option><option value="overdue">Overdue</option><option value="today">Due today</option><option value="week">This week</option>
          </select>
          <button className="clear" onClick={() => setFilters({ customer: '', priority: '', type: '', due: '' })}>Clear filters</button>
        </div>
        <div className="board">
          {COLUMNS.map(col => {
            const items = visibleTasks.filter(t => t.status === col.id);
            return (
              <div key={col.id} className="col"
                onDragOver={e => { e.preventDefault(); (e.currentTarget as HTMLElement).classList.add('drag-over'); }}
                onDragLeave={e => (e.currentTarget as HTMLElement).classList.remove('drag-over')}
                onDrop={e => { e.preventDefault(); (e.currentTarget as HTMLElement).classList.remove('drag-over'); const id = e.dataTransfer.getData('text/plain'); if (id) moveTask(id, col.id); }}>
                <div className="col-h"><span className="cdot" style={{ background: col.color }} /><span className="cname">{col.name}</span><span className="ccount">{items.length}</span></div>
                {items.map(t => (
                  <div key={t.id} className="card" draggable onClick={() => setTaskDraft(t)}
                    onDragStart={e => { e.dataTransfer.setData('text/plain', t.id); (e.currentTarget as HTMLElement).classList.add('dragging'); }}
                    onDragEnd={e => (e.currentTarget as HTMLElement).classList.remove('dragging')}>
                    <div className="c-top"><span className="c-cust">{custName(t.customer_id)}</span><PriorityChip p={t.priority} /></div>
                    <div className="c-title">{t.title}</div>
                    <div className="c-meta-row"><TypeChip t={t.type} /><WsLink url={t.workspace} /></div>
                    {!!(t.tags || []).length && <div className="c-tags">{t.tags.slice(0, 3).map(tg => <span key={tg} className="tag">{tg}</span>)}</div>}
                    <div className="c-foot"><Due s={t.due_date} /><span className="src">{t.source === 'email' ? 'Email' : 'Manual'}{t.time_min ? ` · ${fmtTime(t.time_min)}` : ''}</span></div>
                  </div>
                ))}
                <button className="col-add" onClick={() => setTaskDraft(emptyTask(col.id))}>+ Add task</button>
              </div>
            );
          })}
        </div>
      </>
    );
  }

  function CustomersView() {
    const term = search.trim().toLowerCase();
    const list = customers.filter(c => !term || `${c.name} ${c.org ?? ''}`.toLowerCase().includes(term));
    return (
      <>
        <div className="view-head"><div className="vh-sub">{customers.length} customers</div>
          <button className="btn primary" onClick={() => setCustDraft({ name: '', org: '', instance: '', workspace: '', email_domain: '' })}>+ Add customer</button></div>
        <div className="cust-grid">
          {list.map(c => {
            const openTasks = tasks.filter(t => t.customer_id === c.id && t.status !== 'completed');
            const top = (['urgent', 'high', 'medium', 'low'] as Priority[]).find(p => openTasks.some(t => t.priority === p)) ?? 'low';
            return (
              <div key={c.id} className="cust-card" onClick={() => setCustDraft(c)}>
                <div className="ch"><div className="avatar">{c.name.slice(0, 2).toUpperCase()}</div><div><div className="cn">{c.name}</div><div className="co">{c.org}</div></div></div>
                <div className="cust-meta">
                  <div><div className="k">Zendesk</div><div className="v">{c.instance || '-'}</div></div>
                  <div><div className="k">Open tasks</div><div className="v">{openTasks.length}</div></div>
                  <div><div className="k">Last contact</div><div className="v">{c.last_comm ? daysAgo(c.last_comm) : '-'}</div></div>
                  <div><div className="k">Top priority</div><div className="v"><PriorityChip p={top} /></div></div>
                </div>
              </div>
            );
          })}
        </div>
        {!list.length && <div className="empty">No customers match your search</div>}
      </>
    );
  }

  function ReportsView() {
    const completed = tasks.filter(t => t.status === 'completed');
    const open = tasks.filter(t => t.status !== 'completed');
    const timeByCust: Record<string, number> = {};
    tasks.forEach(t => { const k = t.customer_id ?? 'none'; timeByCust[k] = (timeByCust[k] || 0) + (t.time_min || 0); });
    const timeRows = Object.entries(timeByCust).filter(r => r[1] > 0).sort((a, b) => b[1] - a[1]);
    const maxTime = Math.max(1, ...timeRows.map(r => r[1]));
    const byStatus = COLUMNS.map(c => [c, tasks.filter(t => t.status === c.id).length] as const);
    const maxStatus = Math.max(1, ...byStatus.map(r => r[1]));
    const Stat = ({ label, value, sub }: any) => <div className="stat"><div className="label">{label}</div><div className="value">{value}</div><div className="sub">{sub}</div></div>;
    return (
      <>
        <div className="stat-grid">
          <Stat label="Completed" value={completed.length} sub="All time" />
          <Stat label="Open tasks" value={open.length} sub="Across all customers" />
          <Stat label="Customers" value={customers.length} sub="Active accounts" />
          <Stat label="Tracked time" value={fmtTime(Object.values(timeByCust).reduce((a, b) => a + b, 0))} sub="Logged on all tasks" />
        </div>
        <div className="report-grid">
          <div className="panel"><div className="panel-h"><h2>Time spent per customer</h2></div><div className="panel-b">
            {timeRows.length ? timeRows.map(([cid, m]) => (
              <div key={cid} className="bar-row"><div className="bl">{custName(cid === 'none' ? null : cid)}</div>
                <div className="bar-track"><div className="bar-fill" style={{ width: `${(m / maxTime) * 100}%` }} /></div><div className="bv" style={{ width: 48 }}>{fmtTime(m)}</div></div>
            )) : <div className="empty">No time tracked yet</div>}
          </div></div>
          <div className="panel"><div className="panel-h"><h2>Tasks by stage</h2></div><div className="panel-b">
            {byStatus.map(([c, n]) => (
              <div key={c.id} className="bar-row"><div className="bl">{c.name}</div>
                <div className="bar-track"><div className="bar-fill" style={{ width: `${(n / maxStatus) * 100}%`, background: c.color }} /></div><div className="bv">{n}</div></div>
            ))}
          </div></div>
        </div>
      </>
    );
  }

  // ============ Modals ============
  function TaskModal() {
    const [d, setD] = useState<Partial<Task>>(taskDraft!);
    const set = (k: keyof Task, v: any) => setD(p => ({ ...p, [k]: v }));
    return (
      <div className="overlay open" onClick={e => { if (e.target === e.currentTarget) setTaskDraft(null); }}>
        <div className="modal" role="dialog" aria-modal="true">
          <div className="modal-h"><h3>{d.id ? 'Edit task' : 'New task'}</h3><button className="x" onClick={() => setTaskDraft(null)}>×</button></div>
          <div className="modal-b">
            <div className="field"><label>Title</label><input value={d.title ?? ''} onChange={e => set('title', e.target.value)} placeholder="e.g. Configure SLA policy for Espira" autoFocus /></div>
            <div className="field"><label>Task type</label>
              <div className="seg">{(Object.keys(TYPES) as TaskType[]).map(k => (
                <button key={k} type="button" className={d.type === k ? 'on' : ''} onClick={() => set('type', k)}>{TYPES[k]}</button>))}
              </div>
            </div>
            <div className="field"><label>Description</label><textarea value={d.description ?? ''} onChange={e => set('description', e.target.value)} placeholder="Details, context, or pasted email body..." /></div>
            <div className="field-row">
              <div className="field"><label>Customer</label>
                <select value={d.customer_id ?? ''} onChange={e => set('customer_id', e.target.value || null)}>
                  <option value="">Unassigned</option>{customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select></div>
              <div className="field"><label>Column</label>
                <select value={d.status} onChange={e => set('status', e.target.value as TaskStatus)}>
                  {COLUMNS.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select></div>
            </div>
            <div className="field"><label>Workspace link</label><input type="url" value={d.workspace ?? ''} onChange={e => set('workspace', e.target.value)} placeholder="https://customer.zendesk.com/agent/..." /></div>
            <div className="field-row-3">
              <div className="field"><label>Priority</label>
                <select value={d.priority} onChange={e => set('priority', e.target.value as Priority)}>{(Object.keys(PRIORITIES) as Priority[]).map(p => <option key={p} value={p}>{PRIORITIES[p]}</option>)}</select></div>
              <div className="field"><label>Due date</label><input type="date" value={d.due_date ?? ''} onChange={e => set('due_date', e.target.value || null)} /></div>
              <div className="field"><label>Time (min)</label><input type="number" min={0} step={15} value={d.time_min ?? 0} onChange={e => set('time_min', parseInt(e.target.value, 10) || 0)} /></div>
            </div>
            <div className="field"><label>Tags (comma separated)</label>
              <input value={(d.tags ?? []).join(', ')} onChange={e => set('tags', e.target.value.split(',').map(s => s.trim()).filter(Boolean))} placeholder="implementation, sla" /></div>
          </div>
          <div className="modal-f">
            {d.id ? <button className="del-btn" onClick={() => deleteTask(d.id!)}>Delete</button> : <span />}
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn" onClick={() => setTaskDraft(null)}>Cancel</button>
              <button className="btn primary" onClick={() => saveTask(d)}>Save task</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  function CustomerModal() {
    const [d, setD] = useState<Partial<Customer>>(custDraft!);
    const set = (k: keyof Customer, v: any) => setD(p => ({ ...p, [k]: v }));
    return (
      <div className="overlay open" onClick={e => { if (e.target === e.currentTarget) setCustDraft(null); }}>
        <div className="modal" role="dialog" aria-modal="true" style={{ maxWidth: 480 }}>
          <div className="modal-h"><h3>{d.id ? 'Edit customer' : 'New customer'}</h3><button className="x" onClick={() => setCustDraft(null)}>×</button></div>
          <div className="modal-b">
            <div className="field"><label>Customer name</label><input value={d.name ?? ''} onChange={e => set('name', e.target.value)} placeholder="e.g. Espira" autoFocus /></div>
            <div className="field"><label>Organization</label><input value={d.org ?? ''} onChange={e => set('org', e.target.value)} placeholder="e.g. Espira Gruppen AS" /></div>
            <div className="field"><label>Zendesk instance</label><input value={d.instance ?? ''} onChange={e => set('instance', e.target.value)} placeholder="customer.zendesk.com" /></div>
            <div className="field"><label>Workspace link</label><input type="url" value={d.workspace ?? ''} onChange={e => set('workspace', e.target.value)} placeholder="https://customer.zendesk.com/agent" /></div>
            <div className="field"><label>Email domain (for auto-matching incoming mail)</label><input value={d.email_domain ?? ''} onChange={e => set('email_domain', e.target.value)} placeholder="customer.com" /></div>
          </div>
          <div className="modal-f">
            {d.id ? <button className="del-btn" onClick={() => deleteCustomer(d.id!)}>Delete</button> : <span />}
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn" onClick={() => setCustDraft(null)}>Cancel</button>
              <button className="btn primary" onClick={() => saveCustomer(d)}>Save customer</button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
