-- Kundelab Dashboard - Supabase schema + Row Level Security
-- Run this in the Supabase SQL editor (Section 2.3 of the setup guide).
-- Every row is owned by a user (owner_id = auth.uid()) and is only visible to that user.

-- ---------- Enums ----------
create type task_status as enum (
  'inbox','new','todo','in_progress','waiting_customer','waiting_internal','review','completed'
);
create type task_priority as enum ('urgent','high','medium','low');
create type task_type     as enum ('new','modify','delete');
create type task_source   as enum ('email','manual');

-- ---------- Customers ----------
create table public.customers (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references auth.users(id) on delete cascade,
  name        text not null,
  org         text,
  instance    text,           -- e.g. customer.zendesk.com
  workspace   text,           -- full workspace URL
  email_domain text,          -- used to auto-match incoming email to a customer
  last_comm   date,
  created_at  timestamptz not null default now()
);

-- ---------- Tasks ----------
create table public.tasks (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references auth.users(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  title       text not null,
  description text default '',
  status      task_status   not null default 'inbox',
  priority    task_priority not null default 'medium',
  type        task_type     not null default 'new',
  source      task_source   not null default 'manual',
  workspace   text,           -- link to the relevant workspace/ticket
  due_date    date,
  tags        text[] not null default '{}',
  time_min    integer not null default 0,
  approved    boolean not null default true,   -- email tasks can start unapproved
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ---------- Email dedup / audit ----------
-- Written by the server (service role) when processing Graph notifications.
create table public.email_events (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid references auth.users(id) on delete cascade,
  graph_message_id text not null unique,         -- prevents duplicate task creation
  task_id       uuid references public.tasks(id) on delete set null,
  received_at   timestamptz not null default now()
);

-- ---------- Graph subscription bookkeeping ----------
create table public.graph_subscriptions (
  id               uuid primary key default gen_random_uuid(),
  subscription_id  text not null unique,
  expiration       timestamptz not null,
  created_at       timestamptz not null default now()
);

create index on public.tasks (owner_id, status);
create index on public.tasks (owner_id, due_date);
create index on public.customers (owner_id);

-- ---------- updated_at trigger ----------
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;
create trigger tasks_touch before update on public.tasks
  for each row execute function public.touch_updated_at();

-- ---------- Row Level Security ----------
alter table public.customers          enable row level security;
alter table public.tasks              enable row level security;
alter table public.email_events       enable row level security;
alter table public.graph_subscriptions enable row level security;

-- Users can only touch their own rows.
create policy "own customers" on public.customers
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "own tasks" on public.tasks
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "own email_events" on public.email_events
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

-- graph_subscriptions is server-only (service role bypasses RLS); no client policy granted.
