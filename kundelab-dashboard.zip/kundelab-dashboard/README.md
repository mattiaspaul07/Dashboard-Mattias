# Kundelab Consultant Dashboard

Personal Zendesk consultant work dashboard. Next.js (App Router, TypeScript) · Supabase (Postgres + Auth) · Microsoft 365 login · Microsoft Graph email-to-task · deploys to Vercel.

> Status: starter scaffold. The code is written but has **not** been compiled or run in this environment. Expect to run `npm install` and do a debugging pass. The full setup runbook (Azure, Supabase, Vercel, DNS, GDPR) is in the separate **setup guide** document.

## Quick start (local)

```bash
npm install
cp .env.example .env.local   # then fill in the values (see the setup guide)
npm run dev                  # http://localhost:3000
```

Before the app does anything useful you must:
1. Create the Supabase tables — paste `supabase/schema.sql` into the Supabase SQL editor.
2. Enable the Azure auth provider in Supabase and register the login app in Entra (guide Section 3a).
3. Fill `.env.local`.

## Layout

```
app/
  page.tsx                     auth-gated entry; renders the dashboard
  login/page.tsx               "Sign in with Microsoft"
  auth/callback/route.ts       OAuth code exchange
  api/graph/subscribe          create the mailbox subscription (POST once)
  api/graph/renew              cron: extend subscriptions before the ~3-day cap
  api/graph/notifications      webhook: validation handshake + email -> task
  globals.css                  ported design system (deep teal #003231)
components/DashboardApp.tsx    the UI: dashboard, kanban, customers, reports, modals
lib/                           types, supabase clients, graph helpers
supabase/schema.sql            tables + row-level security
middleware.ts                  session refresh + route gating
vercel.json                    renew cron schedule
```

## Email-to-task

The pipeline is real code but inert until you complete Entra setup (guide Section 3b/5) and set `DASHBOARD_OWNER_ID` (your Supabase user id) so the webhook knows which account owns incoming tasks. Email tasks land in `inbox` as unapproved.

## Known gaps / TODO

- Never compiled here — typecheck and fix on first `npm install`.
- `DASHBOARD_OWNER_ID` is read from env as a deliberate single-user shortcut; revisit if this ever becomes multi-user.
- Realtime updates (Supabase channels) not wired yet — current data loads on page load.
- Scope the Graph mail permission to one mailbox via an application access policy before going live.
